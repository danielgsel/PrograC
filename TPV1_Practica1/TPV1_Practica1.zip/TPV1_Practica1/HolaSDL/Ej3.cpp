#include "SDL.h"			
#include "SDL_image.h"
#include "checkML.h"
#include <iostream>
#include "Texture.h"
#include "DOG.h"
#include "Game.h"

void Main() {

	Game* juego = new Game();

	juego->run();
}

